import logo from "./logo.png";
import user from "./user.png"
import dashboard from "./dashboard.png"
import moon from "./moon.png"
import sun from "./sun.png"
import notification from "./notification.png"
import search from "./search.png"
import maintanance from "./maintanance.png"
import team from "./team.png"
import revenue from "./increase.png"
import roommanagment from "./roommanagment.png"
import Hostel from "./Hostel.jpg"
import Hostel1 from "./Hostel1.jpg"
import Hostel2 from "./Hostel2.jpg"
import Hostel3 from "./Hostel3.jpg"
const assets = {
    logo,user,dashboard,moon,sun,notification,search,
    maintanance,team,revenue,roommanagment,Hostel,Hostel1,Hostel2,Hostel3,
};

export default assets;
